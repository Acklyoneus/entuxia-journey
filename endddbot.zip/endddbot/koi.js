/*
    Sc Lumine-MD V2.0
    My Contact 0895-4024-66525
    
    Notes:
    BUKAN BUAT DIJUAL LAGI !!!
   
*/

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')

global.grup = 'https://chat.whatsapp.com/BHCKGobyZQ23r7Yf5qp0UQ'
global.ig = '@fcqqk_'
global.thumb = fs.readFileSync("./datakoi/image/thumb.jpg")
global.email = 'fynnxxc@gmail.com'
global.region = 'indonesia'
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'ᴄʜᴀᴇ'
global.domain = 'https://syaiistore.paneldigital.my.id'
global.apikey2 = 'ptlc_kTcGT4u2qs5kJryCbaGGrliZkNh3o27GC9ZvMRsMn1T' // Isi Apikey Pltc Lu
global.capikey2 = 'ptlc_kTcGT4u2qs5kJryCbaGGrliZkNh3o27GC9ZvMRsMn1T'
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

global.owner = ['6281365388502']

global.keyopenai = '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'
global.ibeng = 'Yl4h5x9wiA'

global.apikoi = 'NBgiJiyBZK' // ambil di https://api.koi.pics

global.botname = 'ʟᴜᴍɪɴᴇ - ᴍᴅ'
global.packname = 'ʟᴜᴍɪɴᴇ - ᴍᴅ'
global.author = `ʟᴜᴍɪɴᴇ - ᴍᴅ`
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'ʟᴜᴍɪɴᴇ - ᴍᴅ'
global.sp = '⭔'

global.mess = {
    success: '🤗 Done, Oke Desu~',
    admin: '❗Perintah Ini Hanya Bisa Digunakan Oleh Admin Group !',
    botAdmin: '❗Perintah Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group !',
    owner: '❗Perintah Ini Hanya Bisa Digunakan Oleh Owner !',
    group: '❗Perintah Ini Hanya Bisa Digunakan Di Group Chat !',
    bot: '🤖 Fitur Khusus Pengguna Nomor Bot !',
    wait: '⏳ Sedang Di Proses !',
    endLimit: '🕊️ Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12 !\n\n🎯 *Premium Cuma 10k Permanen* 😋',
    error: '🚫 Fitur Sedang Error !',
    prem: '🚫 Fitur Khusus Premium!\n\n♨️ Buy Premium Cuma 10k Permanen',
}

global.limitawal = {
    premium: "Infinity",
    free: 100
}

global.multiplier = 1000

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})